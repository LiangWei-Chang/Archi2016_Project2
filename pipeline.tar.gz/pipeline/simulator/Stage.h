/***************************************************

	File: Stage.h

	Author: PinYo

***************************************************/
#ifndef Stage_h
#define Stage_h

void Instruction_Fetch();
void Instruction_Decode();
void Execute();
void Memory_Access();
void Write_Back();

#endif